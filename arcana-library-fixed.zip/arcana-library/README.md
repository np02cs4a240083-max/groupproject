# 📚 Arcana Library

A full-stack library management app — borrow books, manage your shelf, register & log in.

---

## Project Structure

```
arcana-library/
├── database.sql          ← Run this FIRST to set up MySQL
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
└── backend/
    ├── server.js
    ├── db.js
    ├── package.json
    ├── .env              ← Edit your DB credentials here
    ├── middleware/
    │   └── auth.js
    └── routes/
        ├── auth.js
        ├── books.js
        └── borrows.js
```

---

## 🚀 Quick Start

### Step 1 — Set up the database

Make sure MySQL is running, then:

```bash
mysql -u root -p < database.sql
```

This creates the `arcana_library` database, all tables, and seeds 25 books + 1 demo user.

**Demo login:**
- Email: `demo@arcana.lib`
- Password: `demo1234`

---

### Step 2 — Configure environment

Edit `backend/.env`:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password   # ← change this
DB_NAME=arcana_library
JWT_SECRET=arcana_super_secret_key_2026
PORT=3000
```

---

### Step 3 — Install dependencies & start

```bash
cd backend
npm install
npm start          # production
# or
npm run dev        # with auto-reload (nodemon)
```

---

### Step 4 — Open the app

Visit **http://localhost:3000** in your browser.

---

## API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | ✗ | Register new user |
| POST | `/api/auth/login` | ✗ | Login, get JWT token |
| GET | `/api/books` | ✗ | List/search/filter books |
| GET | `/api/books/:id` | ✗ | Get single book |
| POST | `/api/borrows/:bookId` | ✅ | Borrow a book |
| PUT | `/api/borrows/:bookId/return` | ✅ | Return a book |
| GET | `/api/borrows/myshelf/list` | ✅ | Get your borrowed books |

### Query params for `GET /api/books`

| Param | Example | Description |
|-------|---------|-------------|
| `search` | `?search=dune` | Search title, author, genre |
| `genre` | `?genre=Sci-Fi` | Filter by genre |
| `available` | `?available=true` | Only available books |
| `new_arrival` | `?new_arrival=true` | New arrivals only |
| `popular` | `?popular=true` | Sort by borrow count |
| `sort` | `?sort=rating` | Sort: `title` \| `author` \| `rating` |

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `ER_ACCESS_DENIED_ERROR` | Check `DB_USER` / `DB_PASSWORD` in `.env` |
| `ER_BAD_DB_ERROR` | Run `database.sql` first |
| `Cannot find module '../middleware/auth'` | Make sure you're running from the `backend/` folder |
| Port already in use | Change `PORT` in `.env` |
