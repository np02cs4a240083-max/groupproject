-- ============================================================
--  Arcana Library  –  Database Setup
--  Run this file once to create and seed the database.
--  Usage: mysql -u root -p < database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS arcana_library
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE arcana_library;

-- ── USERS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(120)  NOT NULL,
  email      VARCHAR(191)  NOT NULL UNIQUE,
  password   VARCHAR(255)  NOT NULL,
  created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── BOOKS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS books (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title         VARCHAR(255) NOT NULL,
  author        VARCHAR(180) NOT NULL,
  genre         VARCHAR(80)  NOT NULL,
  cover_color   VARCHAR(20)  NOT NULL DEFAULT '#4a6741',
  rating        DECIMAL(3,1) NOT NULL DEFAULT 0.0,
  available     BOOLEAN      NOT NULL DEFAULT TRUE,
  is_new_arrival BOOLEAN     NOT NULL DEFAULT FALSE,
  borrow_count  INT UNSIGNED NOT NULL DEFAULT 0,
  created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── BORROWS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS borrows (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  book_id     INT UNSIGNED NOT NULL,
  borrowed_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  due_date    DATE         NOT NULL,
  returned_at TIMESTAMP    NULL DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)  ON DELETE CASCADE,
  FOREIGN KEY (book_id) REFERENCES books(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── INDEXES ──────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_books_genre     ON books(genre);
CREATE INDEX IF NOT EXISTS idx_books_available ON books(available);
CREATE INDEX IF NOT EXISTS idx_borrows_user    ON borrows(user_id);
CREATE INDEX IF NOT EXISTS idx_borrows_book    ON borrows(book_id);

-- ── SEED: BOOKS ──────────────────────────────────────────────
INSERT INTO books (title, author, genre, cover_color, rating, available, is_new_arrival, borrow_count) VALUES
  ('The Name of the Wind',        'Patrick Rothfuss',    'Fantasy',    '#6b3a2a', 4.8, TRUE,  FALSE, 42),
  ('Dune',                        'Frank Herbert',       'Sci-Fi',     '#c9a84c', 4.9, TRUE,  FALSE, 78),
  ('1984',                        'George Orwell',       'Dystopia',   '#2d4a5e', 4.7, TRUE,  FALSE, 95),
  ('The Hitchhiker''s Guide',     'Douglas Adams',       'Sci-Fi',     '#3d6b4a', 4.6, TRUE,  FALSE, 55),
  ('Brave New World',             'Aldous Huxley',       'Dystopia',   '#8b5e3c', 4.5, TRUE,  FALSE, 38),
  ('Neuromancer',                 'William Gibson',      'Sci-Fi',     '#1a3a5c', 4.4, TRUE,  FALSE, 29),
  ('The Hobbit',                  'J.R.R. Tolkien',      'Fantasy',    '#5a7a3a', 4.9, TRUE,  FALSE, 110),
  ('Foundation',                  'Isaac Asimov',        'Sci-Fi',     '#4a3a6b', 4.7, TRUE,  FALSE, 67),
  ('Crime and Punishment',        'Fyodor Dostoevsky',   'Classic',    '#6b4a3a', 4.6, TRUE,  FALSE, 31),
  ('Pride and Prejudice',         'Jane Austen',         'Classic',    '#7a5a8b', 4.8, TRUE,  FALSE, 82),
  ('The Great Gatsby',            'F. Scott Fitzgerald', 'Classic',    '#3a6b5a', 4.3, TRUE,  FALSE, 59),
  ('To Kill a Mockingbird',       'Harper Lee',          'Classic',    '#8b7a4a', 4.8, TRUE,  FALSE, 76),
  ('Atomic Habits',               'James Clear',         'Self-Help',  '#5a8b6b', 4.7, TRUE,  TRUE,  45),
  ('The Psychology of Money',     'Morgan Housel',       'Finance',    '#3a5a8b', 4.6, TRUE,  TRUE,  33),
  ('Sapiens',                     'Yuval Noah Harari',   'History',    '#8b5a3a', 4.8, TRUE,  FALSE, 89),
  ('Educated',                    'Tara Westover',       'Memoir',     '#6b8b5a', 4.7, TRUE,  FALSE, 54),
  ('The Midnight Library',        'Matt Haig',           'Fiction',    '#3a6b8b', 4.5, TRUE,  TRUE,  27),
  ('Project Hail Mary',           'Andy Weir',           'Sci-Fi',     '#8b3a5a', 4.9, TRUE,  TRUE,  62),
  ('A Court of Thorns and Roses', 'Sarah J. Maas',       'Fantasy',    '#8b4a6b', 4.4, TRUE,  TRUE,  48),
  ('The Alchemist',               'Paulo Coelho',        'Fiction',    '#c9844c', 4.5, TRUE,  FALSE, 71),
  ('Thinking, Fast and Slow',     'Daniel Kahneman',     'Psychology', '#4a6b8b', 4.6, TRUE,  FALSE, 39),
  ('The Martian',                 'Andy Weir',           'Sci-Fi',     '#8b5a2a', 4.7, TRUE,  FALSE, 58),
  ('Never Split the Difference',  'Chris Voss',          'Self-Help',  '#5a3a8b', 4.6, TRUE,  TRUE,  22),
  ('Ender''s Game',               'Orson Scott Card',    'Sci-Fi',     '#3a8b5a', 4.7, TRUE,  FALSE, 64),
  ('The Four Agreements',         'Don Miguel Ruiz',     'Self-Help',  '#8b8b3a', 4.4, TRUE,  FALSE, 37);

-- ── SEED: DEMO USER (password: demo1234) ─────────────────────
-- bcrypt hash of "demo1234" with salt rounds 10
INSERT INTO users (name, email, password) VALUES
  ('Demo User', 'demo@arcana.lib',
   '$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHy');
