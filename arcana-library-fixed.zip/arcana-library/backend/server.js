const express = require('express');
const cors    = require('cors');
const path    = require('path');
require('dotenv').config();

const authRoutes   = require('./routes/auth');
const booksRoutes  = require('./routes/books');
const borrowsRoutes = require('./routes/borrows');

const app = express();

app.use(cors());
app.use(express.json());

// Serve frontend static files (sibling "frontend" folder)
app.use(express.static(path.join(__dirname, '../frontend')));

// API Routes
app.use('/api/auth',    authRoutes);
app.use('/api/books',   booksRoutes);
app.use('/api/borrows', borrowsRoutes);

// Catch-all: serve frontend SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅  Arcana Library server running at http://localhost:${PORT}`);
});
