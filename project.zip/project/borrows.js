const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

// POST /api/borrows/:bookId  — borrow a book (requires login)
router.post('/:bookId', auth, async (req, res) => {
  const bookId = req.params.bookId;
  const userId = req.user.id;

  try {
    // Check book availability
    const [[book]] = await db.query('SELECT * FROM books WHERE id = ?', [bookId]);
    if (!book) return res.status(404).json({ error: 'Book not found' });
    if (!book.available) return res.status(400).json({ error: 'Book is currently not available' });

    // Check user doesn't already have it
    const [existing] = await db.query(
      'SELECT id FROM borrows WHERE user_id = ? AND book_id = ? AND returned_at IS NULL',
      [userId, bookId]
    );
    if (existing.length > 0)
      return res.status(400).json({ error: 'You already have this book borrowed' });

    // Due date = 14 days from now
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 14);

    await db.query(
      'INSERT INTO borrows (user_id, book_id, due_date) VALUES (?, ?, ?)',
      [userId, bookId, dueDate.toISOString().slice(0, 10)]
    );

    // Mark book unavailable and increment borrow count
    await db.query(
      'UPDATE books SET available = FALSE, borrow_count = borrow_count + 1 WHERE id = ?',
      [bookId]
    );

    res.json({ message: 'Book borrowed successfully', due_date: dueDate.toISOString().slice(0, 10) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/borrows/:bookId/return  — return a book (requires login)
router.put('/:bookId/return', auth, async (req, res) => {
  const bookId = req.params.bookId;
  const userId = req.user.id;

  try {
    const [borrows] = await db.query(
      'SELECT * FROM borrows WHERE user_id = ? AND book_id = ? AND returned_at IS NULL',
      [userId, bookId]
    );
    if (borrows.length === 0)
      return res.status(400).json({ error: 'No active borrow found for this book' });

    await db.query(
      'UPDATE borrows SET returned_at = NOW() WHERE id = ?',
      [borrows[0].id]
    );

    await db.query('UPDATE books SET available = TRUE WHERE id = ?', [bookId]);

    res.json({ message: 'Book returned successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/borrows/myshelf  — get current user's borrowed books (requires login)
router.get('/myshelf/list', auth, async (req, res) => {
  const userId = req.user.id;

  try {
    const [borrows] = await db.query(
      `SELECT b.*, br.borrowed_at, br.due_date, br.returned_at, br.id AS borrow_id
       FROM borrows br
       JOIN books b ON br.book_id = b.id
       WHERE br.user_id = ? AND br.returned_at IS NULL
       ORDER BY br.borrowed_at DESC`,
      [userId]
    );
    res.json(borrows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
