const API = 'http://localhost:3000/api';

// ── STATE ─────────────────────────────────────────
let currentUser = null;
let currentGenre = 'All';
let currentSort  = 'title';
let filterAvailable = false;
let filterNew       = false;
let filterPopular   = false;
let searchQuery     = '';

// ── INIT ──────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadSession();
  loadBooks();
  bindEvents();
});

function loadSession() {
  const token = localStorage.getItem('arcana_token');
  const user  = localStorage.getItem('arcana_user');
  if (token && user) {
    currentUser = JSON.parse(user);
    updateHeader();
  }
}

function updateHeader() {
  const btn = document.getElementById('btn-signin');
  if (currentUser) {
    btn.textContent = currentUser.name.split(' ')[0];
    btn.style.background = '#4a6741';
  } else {
    btn.textContent = 'Sign In';
    btn.style.background = '#9b3a1a';
  }
}

// ── EVENTS ────────────────────────────────────────
function bindEvents() {
  // Search
  document.getElementById('search-btn').addEventListener('click', () => {
    searchQuery = document.getElementById('search-input').value.trim();
    loadBooks();
  });
  document.getElementById('search-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      searchQuery = e.target.value.trim();
      loadBooks();
    }
  });

  // Genre tags
  document.querySelectorAll('.genre-tag').forEach(tag => {
    tag.addEventListener('click', e => {
      e.preventDefault();
      document.querySelectorAll('.genre-tag').forEach(t => t.classList.remove('active'));
      tag.classList.add('active');
      currentGenre = tag.dataset.genre;
      loadBooks();
    });
  });

  // Filters
  document.getElementById('filter-available').addEventListener('change', e => {
    filterAvailable = e.target.checked;
    loadBooks();
  });
  document.getElementById('filter-new').addEventListener('change', e => {
    filterNew = e.target.checked;
    loadBooks();
  });
  document.getElementById('filter-popular').addEventListener('change', e => {
    filterPopular = e.target.checked;
    loadBooks();
  });

  // Sort
  document.querySelectorAll('input[name="sort"]').forEach(radio => {
    radio.addEventListener('change', e => {
      currentSort = e.target.value;
      loadBooks();
    });
  });

  // Nav: My Shelf
  document.getElementById('nav-shelf').addEventListener('click', e => {
    e.preventDefault();
    if (!currentUser) { openAuthModal(); return; }
    openShelfModal();
  });

  // Nav: New Arrivals
  document.getElementById('nav-new').addEventListener('click', e => {
    e.preventDefault();
    document.getElementById('filter-new').checked = true;
    filterNew = true;
    setNavActive('nav-new');
    loadBooks();
  });

  // Nav: Browse
  document.getElementById('nav-browse').addEventListener('click', e => {
    e.preventDefault();
    resetFilters();
    setNavActive('nav-browse');
    loadBooks();
  });

  // Sign In button
  document.getElementById('btn-signin').addEventListener('click', () => {
    if (currentUser) { openShelfModal(); }
    else { openAuthModal(); }
  });

  // Auth Modal
  document.getElementById('modal-close').addEventListener('click', closeAuthModal);
  document.getElementById('modal-overlay').addEventListener('click', e => {
    if (e.target === document.getElementById('modal-overlay')) closeAuthModal();
  });
  document.getElementById('tab-login').addEventListener('click', () => switchTab('login'));
  document.getElementById('tab-register').addEventListener('click', () => switchTab('register'));
  document.getElementById('login-submit').addEventListener('click', handleLogin);
  document.getElementById('reg-submit').addEventListener('click', handleRegister);

  // Shelf Modal
  document.getElementById('shelf-close').addEventListener('click', closeShelfModal);
  document.getElementById('shelf-overlay').addEventListener('click', e => {
    if (e.target === document.getElementById('shelf-overlay')) closeShelfModal();
  });
}

function setNavActive(id) {
  document.querySelectorAll('nav a').forEach(a => a.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function resetFilters() {
  filterAvailable = false;
  filterNew = false;
  filterPopular = false;
  searchQuery = '';
  currentGenre = 'All';
  document.getElementById('filter-available').checked = false;
  document.getElementById('filter-new').checked = false;
  document.getElementById('filter-popular').checked = false;
  document.getElementById('search-input').value = '';
  document.querySelectorAll('.genre-tag').forEach(t => t.classList.remove('active'));
  document.querySelector('.genre-tag[data-genre="All"]').classList.add('active');
}

// ── LOAD BOOKS ────────────────────────────────────
async function loadBooks() {
  const grid = document.getElementById('books-grid');
  grid.innerHTML = '<div class="loading">Loading books…</div>';

  const params = new URLSearchParams();
  if (searchQuery)       params.set('search', searchQuery);
  if (currentGenre !== 'All') params.set('genre', currentGenre);
  if (filterAvailable)   params.set('available', 'true');
  if (filterNew)         params.set('new_arrival', 'true');
  if (filterPopular)     params.set('popular', 'true');
  params.set('sort', currentSort);

  try {
    const res  = await fetch(`${API}/books?${params}`);
    const data = await res.json();
    renderBooks(data.books);
    renderStats(data.stats);
  } catch (err) {
    grid.innerHTML = '<div class="loading">Could not connect to server. Make sure the backend is running.</div>';
  }
}

function renderBooks(books) {
  const grid = document.getElementById('books-grid');
  document.getElementById('book-count').textContent = books.length;

  if (books.length === 0) {
    grid.innerHTML = '<div class="loading">No books found.</div>';
    return;
  }

  grid.innerHTML = books.map(book => `
    <div class="book-card">
      <div class="book-cover" style="background:${book.cover_color};">
        <span class="avail-badge ${book.available ? '' : 'out'}">
          ${book.available ? 'Available' : 'Borrowed'}
        </span>
        <div class="book-cover-title">${book.title}</div>
      </div>
      <div class="book-info">
        <div class="book-title">${book.title}</div>
        <div class="book-author">${book.author}</div>
        <div class="book-foot">
          <span class="genre-pill">${book.genre}</span>
          <span class="rating">★ ${Number(book.rating).toFixed(1)}</span>
        </div>
        <button
          class="borrow-btn ${book.available ? '' : 'unavail'}"
          onclick="handleBorrow(${book.id}, ${book.available})"
          ${book.available ? '' : 'disabled'}
        >
          ${book.available ? 'Borrow' : 'Unavailable'}
        </button>
      </div>
    </div>
  `).join('');
}

function renderStats(stats) {
  if (!stats) return;
  document.getElementById('stat-books').textContent   = Number(stats.total_books).toLocaleString();
  document.getElementById('stat-authors').textContent = Number(stats.total_authors).toLocaleString();
  document.getElementById('stat-members').textContent = Number(stats.total_members).toLocaleString();
}

// ── BORROW ────────────────────────────────────────
async function handleBorrow(bookId, available) {
  if (!available) return;
  if (!currentUser) {
    showToast('Please sign in to borrow books', 'error');
    openAuthModal();
    return;
  }

  try {
    const res  = await fetch(`${API}/borrows/${bookId}`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('arcana_token')}` }
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || 'Could not borrow book', 'error');
      return;
    }
    showToast(`Borrowed! Due back by ${data.due_date}`, 'success');
    loadBooks();
  } catch {
    showToast('Server error. Try again.', 'error');
  }
}

// ── MY SHELF ──────────────────────────────────────
async function openShelfModal() {
  document.getElementById('shelf-overlay').classList.add('open');
  loadShelf();
}

function closeShelfModal() {
  document.getElementById('shelf-overlay').classList.remove('open');
}

async function loadShelf() {
  const content = document.getElementById('shelf-content');
  content.innerHTML = '<div class="loading">Loading your shelf…</div>';

  try {
    const res   = await fetch(`${API}/borrows/myshelf/list`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('arcana_token')}` }
    });
    const books = await res.json();

    if (!books.length) {
      content.innerHTML = '<div class="shelf-empty">Your shelf is empty. Go borrow something!</div>';
      return;
    }

    content.innerHTML = books.map(b => `
      <div class="shelf-book" id="shelf-item-${b.id}">
        <div class="shelf-cover" style="background:${b.cover_color};border-radius:4px;"></div>
        <div class="shelf-info">
          <div class="shelf-title">${b.title}</div>
          <div class="shelf-author">${b.author}</div>
          <div class="shelf-due">Due: ${new Date(b.due_date).toLocaleDateString()}</div>
        </div>
        <button class="return-btn" onclick="handleReturn(${b.id})">Return</button>
      </div>
    `).join('');
  } catch {
    content.innerHTML = '<div class="shelf-empty">Could not load shelf.</div>';
  }
}

async function handleReturn(bookId) {
  try {
    const res  = await fetch(`${API}/borrows/${bookId}/return`, {
      method: 'PUT',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('arcana_token')}` }
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || 'Could not return book', 'error');
      return;
    }
    showToast('Book returned successfully!', 'success');
    loadShelf();
    loadBooks();
  } catch {
    showToast('Server error. Try again.', 'error');
  }
}

// ── AUTH MODAL ────────────────────────────────────
function openAuthModal() {
  document.getElementById('modal-overlay').classList.add('open');
}

function closeAuthModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  document.getElementById('login-error').textContent = '';
  document.getElementById('reg-error').textContent   = '';
}

function switchTab(tab) {
  const isLogin = tab === 'login';
  document.getElementById('tab-login').classList.toggle('active', isLogin);
  document.getElementById('tab-register').classList.toggle('active', !isLogin);
  document.getElementById('form-login').style.display    = isLogin ? 'block' : 'none';
  document.getElementById('form-register').style.display = isLogin ? 'none'  : 'block';
}

async function handleLogin() {
  const email    = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const errEl    = document.getElementById('login-error');

  if (!email || !password) { errEl.textContent = 'Fill in all fields'; return; }

  try {
    const res  = await fetch(`${API}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Login failed'; return; }

    localStorage.setItem('arcana_token', data.token);
    localStorage.setItem('arcana_user',  JSON.stringify(data.user));
    currentUser = data.user;
    updateHeader();
    closeAuthModal();
    showToast(`Welcome back, ${data.user.name.split(' ')[0]}!`, 'success');
  } catch {
    errEl.textContent = 'Server error. Try again.';
  }
}

async function handleRegister() {
  const name     = document.getElementById('reg-name').value.trim();
  const email    = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;
  const errEl    = document.getElementById('reg-error');

  if (!name || !email || !password) { errEl.textContent = 'Fill in all fields'; return; }
  if (password.length < 6)          { errEl.textContent = 'Password must be at least 6 characters'; return; }

  try {
    const res  = await fetch(`${API}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Registration failed'; return; }

    localStorage.setItem('arcana_token', data.token);
    localStorage.setItem('arcana_user',  JSON.stringify(data.user));
    currentUser = data.user;
    updateHeader();
    closeAuthModal();
    showToast(`Welcome to Arcana, ${data.user.name.split(' ')[0]}!`, 'success');
  } catch {
    errEl.textContent = 'Server error. Try again.';
  }
}

// ── TOAST ─────────────────────────────────────────
function showToast(msg, type = '') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className   = `toast show ${type}`;
  setTimeout(() => { toast.className = 'toast'; }, 3000);
}
