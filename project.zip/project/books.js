const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/books
// Query params: search, genre, available, new_arrival, popular, sort
router.get('/', async (req, res) => {
  try {
    const { search, genre, available, new_arrival, popular, sort } = req.query;

    let sql = 'SELECT * FROM books WHERE 1=1';
    const params = [];

    if (search) {
      sql += ' AND (title LIKE ? OR author LIKE ? OR genre LIKE ?)';
      const like = `%${search}%`;
      params.push(like, like, like);
    }

    if (genre && genre !== 'All') {
      sql += ' AND genre = ?';
      params.push(genre);
    }

    if (available === 'true') {
      sql += ' AND available = TRUE';
    }

    if (new_arrival === 'true') {
      sql += ' AND is_new_arrival = TRUE';
    }

    if (popular === 'true') {
      sql += ' ORDER BY borrow_count DESC';
    } else if (sort === 'rating') {
      sql += ' ORDER BY rating DESC';
    } else if (sort === 'author') {
      sql += ' ORDER BY author ASC';
    } else {
      sql += ' ORDER BY title ASC';
    }

    const [books] = await db.query(sql, params);

    // Get stats
    const [[stats]] = await db.query(`
      SELECT 
        COUNT(*) AS total_books,
        COUNT(DISTINCT author) AS total_authors,
        (SELECT COUNT(*) FROM users) AS total_members
      FROM books
    `);

    res.json({ books, stats });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/books/:id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM books WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Book not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
